import { Component } from '@angular/core';
@Component({
  selector: 'app-use-case',

  templateUrl: './use-case.component.html',
  styleUrl: './use-case.component.scss'
})
export class UseCaseComponent {

}
