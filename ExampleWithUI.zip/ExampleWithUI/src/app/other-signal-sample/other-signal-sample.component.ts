import { Component } from '@angular/core';

@Component({
  selector: 'app-other-signal-sample',

  templateUrl: './other-signal-sample.component.html',
  styleUrl: './other-signal-sample.component.scss'
})
export class OtherSignalSampleComponent {

}
