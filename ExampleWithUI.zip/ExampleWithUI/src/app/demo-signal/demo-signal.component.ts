import { Component } from '@angular/core';
import { WithSignalComponent } from '../with-signal/with-signal.component';

@Component({
  selector: 'app-demo-signal',
  templateUrl: './demo-signal.component.html',
  styleUrl: './demo-signal.component.scss'
})
export class DemoSignalComponent {

}
