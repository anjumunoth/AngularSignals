import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TwoWayBindingExamplesComponent } from './two-way-binding-examples.component';

describe('TwoWayBindingExamplesComponent', () => {
  let component: TwoWayBindingExamplesComponent;
  let fixture: ComponentFixture<TwoWayBindingExamplesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TwoWayBindingExamplesComponent]
    });
    fixture = TestBed.createComponent(TwoWayBindingExamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
