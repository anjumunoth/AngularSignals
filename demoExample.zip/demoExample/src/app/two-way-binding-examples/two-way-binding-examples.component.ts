import { Component } from '@angular/core';

@Component({
  selector: 'app-two-way-binding-examples',
  templateUrl: './two-way-binding-examples.component.html',
  styleUrls: ['./two-way-binding-examples.component.css']
})
export class TwoWayBindingExamplesComponent {
  userName:string;
  password:string;
  countries:string[];
  countrySelected:string;
  subscriptionRequired:string;
  empArr:any;
  showEditEmployee:boolean;
  empToBeEdited:any;
  constructor()
{
  this.empToBeEdited=null;
  this.showEditEmployee=false;
  this.subscriptionRequired="YES";
  this.countries=["USA","India","Australia","South Africa","Zimbawe"]
  this.countrySelected=this.countries[0];
  this.userName="sara";
  this.password="sara123#";
  this.empArr=[{empId:101,empName:"Asha",salary:1001,deptId:"D1"},
    {empId:102,empName:"Gaurav",salary:2000,deptId:"D1"},
    {empId:103,empName:"Karan",salary:2000,deptId:"D2"},
    {empId:104,empName:"Kishan",salary:3000,deptId:"D1"},
    {empId:105,empName:"Keshav",salary:3500,deptId:"D2"},
    {empId:106,empName:"Pran",salary:4000,deptId:"D3"},
    {empId:107,empName:"Saurav",salary:3800,deptId:"D3"}]
    
}

  changeEventHandler(ev:any)
  {
    // whenver the text box loses focus
    console.log("Inside the change event handler",ev.target.value);
    //this.userName=ev.target.value;

  }
  inputEventHandler(ev:any)
  {
    // whenever the user types in the text box
    console.log("Inside the input event handler",ev.target.value)
    this.userName=ev.target.value;
  }
  changeCountryEventHandler(ev:any)
  {
    this.countrySelected=ev.target.value;
  }
  editEventHandler(empToBeEdited:any)
  {
    this.showEditEmployee=true;
    this.empToBeEdited=empToBeEdited;
  }
}
