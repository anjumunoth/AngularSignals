import { CustomToolTipDirective } from './custom-tool-tip.directive';

describe('CustomToolTipDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomToolTipDirective();
    expect(directive).toBeTruthy();
  });
});
