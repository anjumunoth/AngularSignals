import { DecimalPipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'distance'
})
export class DistancePipe implements PipeTransform {

  transform(value: number, arg1:string="kms"): string {
    // Assumptions:value is already in kms
    // Logic -- convert value to the arg1 measurement unit
    // default value of arg1: kms
    // how to use an inbuilt pipe in the custom pipe
    var numberPipe=new DecimalPipe("en-US");
    
    //convert the data to the arg1 measurement unit
    if( value <=0)
    {
      return value.toString();
    }
    // 1.62kms == 1 mile
    //convert kms to mile :value/1.62
    var numberFormat:string="3.2-5"
    switch(arg1)
    {
      case "kms":return numberPipe.transform(value,numberFormat)+"kms";break;
      case "mtrs":return numberPipe.transform((value *1000),numberFormat)+"mtrs"; break;
      case "mile":return numberPipe.transform((value/1.62),numberFormat)+"miles"; break;
      default: return numberPipe.transform(value,numberFormat)+"kms";
      }
      
    }
    
  }


