import { Component } from '@angular/core';
import { CartManagementService } from '../Services/cart-management.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
  cartsArr:any;
  constructor(private cartService:CartManagementService)
  {
    this.cartsArr=this.cartService.getCartsArr();
  }

}
