import { booleanAttribute, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit,OnChanges
{
  // add some events -- events for sending data from child to parent
  @Output() onUpdationOfCtr:EventEmitter<number>;
  @Output() onUpdationOfCompanyName:EventEmitter<string>;
  // data from the parent
  @Input({
    transform: booleanAttribute
  }) showBorder:boolean;
  @Input() incValue:number;
  @Input() ctr:number;
  @Input({
    transform:(value:any)=>{
      return ([...(
          value.filter((emp:any)=>{
            return (emp.empName.indexOf("r") >=0);
          })
      )
    ]);
      
    }
  })employeeArr:any;
  @Input({required:true}) myCompanyName:string;
  @Input({
    required:true,
    alias:"emp",
    transform:(value:any)=>{
      
      return {...value};
    }  
   }) employeeDetails :any;
  constructor()
  {
    this.onUpdationOfCtr=new EventEmitter<number>();
    this.onUpdationOfCompanyName=new EventEmitter<string>();
    this.showBorder=false;
    this.incValue=0;
    this.ctr=0;
    this.myCompanyName="dan and bradstreet";
    this.employeeDetails=null;
    this.employeeArr=[];
    
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log("Changes object in child component",changes)
  }
  ngOnInit(): void {
    console.log(`Company Name : ${this.myCompanyName}` );// dnb 
    console.log("employee arr",this.employeeArr)
    //this.emp={...this.emp};// why are u doing this
    // filter out the elements which has r in it
    //this.employeeArr=this.employeeArr.filter((emp:any)=> emp.empName.indexOf("r") >=0);
   
  }
  changeCompanyNameEventHandler()
  {
    this.myCompanyName="dan and bradstreet";
    this.employeeDetails.salary=100;
    this.onUpdationOfCompanyName.emit(this.myCompanyName);
  }
  incrementCtrEventHandler()
  {
    // triggering the event
    this.onUpdationOfCtr.emit(this.incValue+this.ctr);
  }
}
// <input type="button" value="Confirm" disabled />
// presence of the attribute is equivlaent to disabled=true
// shortcut notation



