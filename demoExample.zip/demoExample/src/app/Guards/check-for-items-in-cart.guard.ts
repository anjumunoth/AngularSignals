import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { CartManagementService } from '../Services/cart-management.service';

export const checkForItemsInCartGuard: CanActivateFn = (route, state) => {
  // check for length of cartArr;
  var cms=inject(CartManagementService);
  var router=inject(Router);
  console.log("Inside check for items route guard");
  if(cms.getCartsArr().length >0)
  {
    return true;
  }
  else
  {
    return router.navigate(["/products"]);
  }
  
};
