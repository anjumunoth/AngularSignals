import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { checkForItemsInCartGuard } from './check-for-items-in-cart.guard';

describe('checkForItemsInCartGuard', () => {
  const executeGuard: CanActivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => checkForItemsInCartGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
