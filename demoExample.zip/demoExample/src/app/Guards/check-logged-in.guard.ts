import { inject } from '@angular/core';
import { CanActivateFn, createUrlTreeFromSnapshot, Router, UrlTree } from '@angular/router';
import { UsersManagementService } from '../Services/users-management.service';

export const checkLoggedInGuard: CanActivateFn = (route, state) => {
  console.log("Route",route);
  console.log("state",state);
  var userService =inject(UsersManagementService);
  console.log("Inside check for logged in  route guard");
  var loggedInStatus:boolean=false;
    //   userService.isloggedIn.subscribe((value)=>{
    //     console.log("New value of logged in in the guard",value)
    //     loggedInStatus=value;
    //   })
    // alert("Logged in status"+loggedInStatus);
    loggedInStatus=userService.currentStatusOfLogIn;
    // route -- details of the route to which we are navigating
    // state -- router state details
    
    // var loginPath:UrlTree=createUrlTreeFromSnapshot(route,["/login"]);
    // return loggedInStatus?true:loginPath;

    if(loggedInStatus)
    {
      return true;
    }
    var router=inject(Router);
    // queryParams : keyword; returnUrl -- custom attribute
    router.navigate(["/login"],{queryParams:{returnUrl:route.url}});
    return false;
};
