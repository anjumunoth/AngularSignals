import { Component } from '@angular/core';
import { ProductsManagementService } from '../Services/products-management.service';
import { ColoursAtComponentLevelService } from '../Services/colours-at-component-level.service';

@Component({
  selector: 'app-service-examples',
  templateUrl: './service-examples.component.html',
  styleUrls: ['./service-examples.component.css'],
  providers:[ColoursAtComponentLevelService]
})
export class ServiceExamplesComponent {
  counter:number;
  selectedColour:string;
  constructor(private productsmanagementService:ProductsManagementService, private coloursService:ColoursAtComponentLevelService)
  {
    this.counter=productsmanagementService.ctr;
    this.selectedColour=coloursService.myColor;//pink
  }
  addEventHandler()
  {
    this.productsmanagementService.incCtr();
    this.counter=this.productsmanagementService.ctr;
  }
  changeColurEventHandler(selColour:string)
  {
    this.coloursService.changeColour(selColour);
    this.selectedColour=this.coloursService.myColor;
  }
}
