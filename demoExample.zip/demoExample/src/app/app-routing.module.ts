import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { MainComponent } from './main/main.component';
import { ProductSearchComponent } from './product-search/product-search.component';
import { ProductManageComponent } from './product-manage/product-manage.component';
import { RegisterModelFormComponent } from './register-model-form/register-model-form.component';
import { Page404Component } from './page404/page404.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { PaymentsComponent } from './payments/payments.component';
import { PaymentByNetBankingComponent } from './payment-by-net-banking/payment-by-net-banking.component';
import { PaymentByWalletComponent } from './payment-by-wallet/payment-by-wallet.component';
import { PaymentByCODComponent } from './payment-by-cod/payment-by-cod.component';
import { PaymentByUpiComponent } from './payment-by-upi/payment-by-upi.component';
import { PaymentByCardComponent } from './payment-by-card/payment-by-card.component';
import { ServiceExamplesComponent } from './service-examples/service-examples.component';
import { ServiceExamples2Component } from './service-examples2/service-examples2.component';
import { RxjsExamplesComponent } from './rxjs-examples/rxjs-examples.component';
import { checkLoggedInGuard } from './Guards/check-logged-in.guard';
import { checkAdminLoginGuard } from './Guards/check-admin-login.guard';
import { checkBeforeLeavingGuard } from './Guards/check-before-leaving.guard';
import { checkForItemsInCartGuard } from './Guards/check-for-items-in-cart.guard';
import { checkLoggedInForChildGuard } from './Guards/check-logged-in-for-child.guard';
import { UsersFromjsonPlaceholderComponent } from './users-fromjson-placeholder/users-fromjson-placeholder.component';
import { DisplayUsersUsingObservableComponent } from './display-users-using-observable/display-users-using-observable.component';
import { UsersFromReqResComponent } from './users-from-req-res/users-from-req-res.component';
import { DebouncingExampleComponent } from './debouncing-example/debouncing-example.component';
import { PayHomeComponent } from './pay/pay-home/pay-home.component';
import { ChangedetectionExampleComponent } from './changedetection-example/changedetection-example.component';
import { AnimationExamplesComponent } from './animation-examples/animation-examples.component';
import { TwoWayBindingExamplesComponent } from './two-way-binding-examples/two-way-binding-examples.component';
import { SignalExample1Component } from './signal-example1/signal-example1.component';

const routes: Routes = [

  {
    path: "payments", component: PaymentsComponent,
    canActivate: [checkLoggedInGuard, checkForItemsInCartGuard],
    canActivateChild: [checkLoggedInForChildGuard],
    children: [
      { path: "paymentByNetBanking", component: PaymentByNetBankingComponent },
      { path: "paymentByWallet", component: PaymentByWalletComponent },
      { path: "paymentByCOD", component: PaymentByCODComponent },
      { path: "paymentByUpi", component: PaymentByUpiComponent },
      { path: "paymentByCard", component: PaymentByCardComponent },
    ]
  },
  { path: "signalExample", component: SignalExample1Component },
  { path: "payHome", component: PayHomeComponent },
  { path: "twoWayBinding", component: TwoWayBindingExamplesComponent },
  { path: "debouncing", component: DebouncingExampleComponent },
  { path: "animationExamples", component: AnimationExamplesComponent },
  { path: "displayUsersFromObservable", component: DisplayUsersUsingObservableComponent },
  { path: "usersFromJsonPlaceHolder", component: UsersFromjsonPlaceholderComponent },
  { path: "usersFromReqRes", component: UsersFromReqResComponent },
  { path: "rxjsExamples", component: RxjsExamplesComponent, canActivate: [checkLoggedInGuard] },
  { path: "productDetails", component: ProductDetailsComponent },
  { path: "serviceExamples", component: ServiceExamplesComponent },
  { path: "serviceExamples2", component: ServiceExamples2Component },
  { path: "productDetails/:pId", component: ProductDetailsComponent },
  { path: "login", component: LoginComponent, canDeactivate: [checkBeforeLeavingGuard] },
  { path: "products", component: MainComponent },
  { path: "product-search", component: ProductSearchComponent },
  { path: "product-manage", component: ProductManageComponent, canActivate: [checkLoggedInGuard, checkAdminLoginGuard] },
  { path: "changeDetection", component: ChangedetectionExampleComponent },
  {
    path: "register", component: RegisterModelFormComponent, canDeactivate: [checkBeforeLeavingGuard]
  },
  // {path:"",component:MainComponent},
  { path: "", redirectTo: "/products", pathMatch: 'full' },

  { path: 'fresh', loadChildren: () => import('./fresh/fresh.module').then(m => m.FreshModule) },

  { path: "**", component: Page404Component },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { bindToComponentInputs: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
