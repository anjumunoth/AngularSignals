import { CheckPasswordStrengthDirective } from './check-password-strength.directive';

describe('CheckPasswordStrengthDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckPasswordStrengthDirective();
    expect(directive).toBeTruthy();
  });
});
