import { Component } from '@angular/core';

@Component({
  selector: 'app-gpay-payment',
  templateUrl: './gpay-payment.component.html',
  styleUrls: ['./gpay-payment.component.css']
})
export class GpayPaymentComponent {

}
