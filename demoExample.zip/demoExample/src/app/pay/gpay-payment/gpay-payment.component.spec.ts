import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GpayPaymentComponent } from './gpay-payment.component';

describe('GpayPaymentComponent', () => {
  let component: GpayPaymentComponent;
  let fixture: ComponentFixture<GpayPaymentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GpayPaymentComponent]
    });
    fixture = TestBed.createComponent(GpayPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
