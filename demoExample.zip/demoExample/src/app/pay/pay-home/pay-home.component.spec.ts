import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayHomeComponent } from './pay-home.component';

describe('PayHomeComponent', () => {
  let component: PayHomeComponent;
  let fixture: ComponentFixture<PayHomeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PayHomeComponent]
    });
    fixture = TestBed.createComponent(PayHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
