import { Component, signal, computed } from '@angular/core';

@Component({
  selector: 'app-signal-example1',
  templateUrl: './signal-example1.component.html',
  styleUrl: './signal-example1.component.css'
})
export class SignalExample1Component {
  ctr = signal<number>(100);
  price: number;
  totalCost = computed(() => this.ctr() * this.price);// cached and memoised
  constructor() {
    this.price = 123.45;
    //this.totalCost.set(1000);//not allowed ;; computed signal are read only signals

  }
  changeQtyHandler(op: string) {
    if (op == "inc") {
      //this.ctr++;
      this.ctr.update(value => value + 1);
    }
    else {
      this.ctr.update(value => value - 1);
    }

  }
  resetCtrHandler() {
    this.ctr.set(100)
  }

}
