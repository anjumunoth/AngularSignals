import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SignalExample1Component } from './signal-example1.component';

describe('SignalExample1Component', () => {
  let component: SignalExample1Component;
  let fixture: ComponentFixture<SignalExample1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SignalExample1Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SignalExample1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
