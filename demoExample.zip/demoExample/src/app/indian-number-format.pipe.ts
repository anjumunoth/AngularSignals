// indian-number.pipe.ts

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'indianNumberFormat'
})
export class IndianNumberFormatPipe implements PipeTransform {
  transform(value: number): string {
    if (value === null || value === undefined) return '';

    // Convert the number to a string
    let stringValue = value.toString();

    // Split the string into parts for rupees and paise (if any)
    let [rupees, paise] = stringValue.split('.');

    // Format rupees part with commas for thousands, lakhs, crores
    let formattedRupees = this.formatIndianRupees(parseInt(rupees, 10));

    // If there are paise, add them with decimal point
    if (paise !== undefined) {
      formattedRupees += '.' + paise;
    }

    // Return the formatted string with ₹ symbol
    return '₹ ' + formattedRupees;
  }

  private formatIndianRupees(value: number): string {
    if (isNaN(value)) return '';

    // Convert number to string and reverse it for easier manipulation
    let stringValue = value.toString().split('').reverse().join('');

    // Split into groups of two digits each
    let groups = stringValue.match(/\d{1,2}/g);

    if (!groups) return '';

    // Reverse back and join with commas
    let formattedString = groups.join(',').split('').reverse().join('');

    return formattedString;
  }
}
