import { Component } from '@angular/core';
import { Products } from '../Products';
import { ProductsManagementService } from '../Services/products-management.service';

@Component({
  selector: 'app-product-search',
  templateUrl: './product-search.component.html',
  styleUrls: ['./product-search.component.css']
})
export class ProductSearchComponent {
  productsArr:Array<Products>;
  searchTerm:string;
  fieldsArr:string[];
  sortFieldName:string
  sortOrder:string;
constructor(private pms:ProductsManagementService)
{
  this.sortFieldName="";
  this.sortOrder="";
  this.productsArr=pms.getProductsArr();
  this.searchTerm="";
  this.fieldsArr=Object.keys(this.productsArr[0]);
}
serachTermKeyPressEventHandler(event:any)
{
  console.log(event.target.value);
  this.searchTerm=event.target.value;

}
sortEventHandler(sortFieldNameElement:any,sortOrderElement:any)
{
  console.log(sortFieldNameElement.options[sortFieldNameElement.selectedIndex].value);
  console.log(sortOrderElement.options[sortOrderElement.selectedIndex].value);
  this.sortOrder=sortOrderElement.options[sortOrderElement.selectedIndex].value;
  this.sortFieldName=sortFieldNameElement.options[sortFieldNameElement.selectedIndex].value;
}
changeEventHandler(ev:any)
{
  console.log("change event triggered",ev.target.selectedIndex);
}


}
