import { Component, OnInit,OnDestroy } from '@angular/core';
import { TalkWithServerService } from '../Services/talk-with-server.service';

@Component({
  selector: 'app-users-from-req-res',
  templateUrl: './users-from-req-res.component.html',
  styleUrls: ['./users-from-req-res.component.css']
})
export class UsersFromReqResComponent implements OnInit,OnDestroy {
  usersArr: any;
  errMessage: any;
  getSubscription:any;
  postSubscription:any;
  constructor(private talkWithServer: TalkWithServerService) {
    this.usersArr = [];
    this.errMessage = "";
  }
  ngOnInit(): void {
    this.getSubscription=this.talkWithServer.getAllUsersFromReqRes()
      .subscribe(
        {
          next: (response: any) => {
            console.log("Response from reqres", response);
            this.usersArr = response.body.data;
          },
          error: (err) => {
            console.log("Error on the get request", err);
            this.errMessage = err;
          }
        }
      )

  }
  addUserEventHandler() {
    var newUser={
      "name": "sara",
      "job": "leader"
  }
    this.postSubscription=this.talkWithServer.addUser(newUser)
    .subscribe({
      next:(response)=>{
        console.log("Response from the post request",response);
        this.usersArr.push(response.body);
      },
      error:(err)=>{
        this.errMessage=err;

      },
      complete:()=>{
        console.log("Response complete");

      }
    })
  }
  ngOnDestroy()
  {
    this.getSubscription.unsubscribe();
    this.postSubscription.unsubscribe();
    alert("All subscriptions unsubscribed")

  }

}
