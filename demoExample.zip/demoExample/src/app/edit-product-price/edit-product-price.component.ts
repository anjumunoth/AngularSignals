import { Component,EventEmitter,Input, Output } from '@angular/core';
import { Products } from '../Products';

@Component({
  selector: 'app-edit-product-price',
  templateUrl: './edit-product-price.component.html',
  styleUrls: ['./edit-product-price.component.css']
})
export class EditProductPriceComponent {
@Input() productToBeEdited:Products|null;
@Output() onConfirmPrice:EventEmitter<Products>;
constructor()
{
  this.productToBeEdited=null;
  this.onConfirmPrice=new EventEmitter<Products>();
}
confirmEventHandler(newProductPrice:string)
{
  // send data to the parent
  if(this.productToBeEdited)
  {
    this.productToBeEdited.price=parseInt(newProductPrice);
    // trigger the event
    this.onConfirmPrice.emit(this.productToBeEdited);
  }

  
}
}
