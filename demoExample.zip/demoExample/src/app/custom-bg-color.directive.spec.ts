import { CustomBgColorDirective } from './custom-bg-color.directive';

describe('CustomBgColorDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomBgColorDirective();
    expect(directive).toBeTruthy();
  });
});
