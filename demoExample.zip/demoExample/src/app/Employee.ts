class Employee
{
    constructor(private empId:number,private empName:string,private salary:number)
    {

    }
}

class Employee1
{
    empId:number;
    empName:string;
    salary:number;
    constructor(empId:number, empName:string, salary:number)
    {
        this.empId=empId;
        this.empName=empName;
        this.salary=salary;
    }
}