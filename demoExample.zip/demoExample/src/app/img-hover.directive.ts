import { Directive, ElementRef,HostListener,Input } from '@angular/core';

@Directive({
  selector: '[appImgHover]'
})
export class ImgHoverDirective {
  initialPath:string;
  @Input() appImgHover:string;
  @HostListener("mouseover") onMouseOver(){
    this.elementRef.nativeElement.src=this.appImgHover;
  }
  @HostListener("mouseout") onMouseOut(){
    this.elementRef.nativeElement.src=this.initialPath;
  }
  constructor(private elementRef:ElementRef) {
    this.initialPath=this.elementRef.nativeElement.src;
    this.appImgHover="";
   }

}
