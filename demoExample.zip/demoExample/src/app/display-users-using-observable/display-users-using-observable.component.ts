import { Component,OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { TalkWithServerService } from '../Services/talk-with-server.service';

@Component({
  selector: 'app-display-users-using-observable',
  templateUrl: './display-users-using-observable.component.html',
  styleUrls: ['./display-users-using-observable.component.css']
})
export class DisplayUsersUsingObservableComponent implements OnInit {
  users$:Observable<any>;
  searchTerm:string;
  searchFieldArr:any;
  sortField:string;
  sortOrder:string;
  
constructor(private talkWithServer:TalkWithServerService)
{
  this.users$=new Observable<any>();
  this.searchTerm="";
    
    this.searchFieldArr=['username'];
    this.sortField="username";
    this.sortOrder="asc";
}
  ngOnInit(): void {
    this.users$=this.talkWithServer.getAllUsersFromJsonPlaceHolder();
  }
  toggleSortOrderForUserName()
  {
    this.sortField="username";
    this.sortOrder=this.sortOrder=="asc"?"desc":"asc";
  }

}
