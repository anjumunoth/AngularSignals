import { Component } from '@angular/core';

@Component({
  selector: 'app-pipe-examples',
  templateUrl: './pipe-examples.component.html',
  styleUrls: ['./pipe-examples.component.css']
})
export class PipeExamplesComponent {
  companyName:string;
  price:number;
  today:Date;
  gokulbday:Date;
  colours:string[];
  emp:any;
  dist1:number;
  
  constructor()
  {
   this.dist1=3456789.56780;
    this.colours=["red","green","blue","orange","yellow"]
    this.companyName="dan&bradstreet";
    this.price=1114456.689366549;// 11,14,456.
    this.today=new Date();
    this.gokulbday=new Date(2024,7,10);
    this.emp={empId:101,empName:"sara",salary:6789}

  }
}
