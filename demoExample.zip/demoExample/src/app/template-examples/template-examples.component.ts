import { Component } from '@angular/core';

@Component({
  selector: 'app-template-examples',
  templateUrl: './template-examples.component.html',
  styleUrls: ['./template-examples.component.css']
})
export class TemplateExamplesComponent {
  today:Date;
  sessionName:string;
  employeeArr:any;
  constructor()
  {
    this.employeeArr=[];
    this.today=new Date();
    this.sessionName="angular";
  }
  changeSessionEventHandler()
  {
    if(this.sessionName=="angular")
    {
      this.sessionName="react";
    }
    else
    {
      this.sessionName="angular";
    }
  }
  addEmployeeEventHandler(empName:any,salary:any)
  {
    var newEmp={empName:empName.value,salary:parseInt(salary.value)};
    this.employeeArr.push(newEmp);
    empName.value="";
    salary.value=""
  }
}
