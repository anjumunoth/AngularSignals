export class Products
{
    productId:number;
    productName:string;
    price:number
    quantity:number;
    imgUrl:string;
    description:string;
    constructor(productId:number,productName:string,price:number,quantity:number,imgUrl:string,description:string)
    {
        this.price=price;
        this.productId=productId;
        this.description=description;
        this.imgUrl=imgUrl;
        this.productName=productName;
        this.quantity=quantity
    }
}