import { AbstractControl, ValidationErrors, ValidatorFn } from "@angular/forms";

export function passwordStrength():ValidatorFn
{
    return (
        (control:AbstractControl):ValidationErrors | null=>{
            //console.log("Inside validator function of passwordStrength",control.value)
            var value=control.value;
            if(!value)
            {
                return null;
            }
            var hasUpperCase=/[A-Z]/.test(value);
            var hasLowerCase=/[a-z]/.test(value);
            var hasNumber=/[0-9]/.test(value);
            var hasSpecialChar=/[!@#$%^&*(),.?":{}|<>]/.test(value);
            var validValue=hasUpperCase&& hasSpecialChar&& hasNumber && hasLowerCase;
            if(validValue)
            {
                return null;
            }
            else
            {
                return {checkPasswordStrength:true}
            }

        }
    )
}