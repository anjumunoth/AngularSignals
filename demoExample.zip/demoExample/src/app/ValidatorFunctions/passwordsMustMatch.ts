import { AbstractControl, FormGroup, ValidationErrors, ValidatorFn } from "@angular/forms";

export function passwordsMustMatch(controlsArr:string[]):any
{
    return (
        (formGroup:FormGroup):any=>{
            //logic is implemented here in inner function
            // get the individuals controls and their respective values
            console.log("Inside passwordMustMatch")
            var passwordControl=formGroup.controls[controlsArr[0]];
            var confirmPasswordControl=formGroup.controls[controlsArr[1]];
            if(!passwordControl || ! confirmPasswordControl)
            {
                return null;
            }
            if(passwordControl.errors || confirmPasswordControl.errors)
            {
                return null;
            }
            // check for equality of values
            if(passwordControl.value == confirmPasswordControl.value)
            {
                confirmPasswordControl.setErrors(null);
                return null;
            }
            else
            {
                // set error on confirmPasswordField
                confirmPasswordControl.setErrors({mustMatch:true});
                return {mustMatch:true};


            }
        }
    )
}