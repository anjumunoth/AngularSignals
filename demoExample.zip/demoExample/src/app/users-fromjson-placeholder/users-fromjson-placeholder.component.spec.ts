import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsersFromjsonPlaceholderComponent } from './users-fromjson-placeholder.component';

describe('UsersFromjsonPlaceholderComponent', () => {
  let component: UsersFromjsonPlaceholderComponent;
  let fixture: ComponentFixture<UsersFromjsonPlaceholderComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UsersFromjsonPlaceholderComponent]
    });
    fixture = TestBed.createComponent(UsersFromjsonPlaceholderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
