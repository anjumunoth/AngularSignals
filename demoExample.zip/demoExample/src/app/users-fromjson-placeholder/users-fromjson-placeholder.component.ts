import { Component, OnInit } from '@angular/core';
import { TalkWithServerService } from '../Services/talk-with-server.service';
import { map } from 'rxjs';

@Component({
  selector: 'app-users-fromjson-placeholder',
  templateUrl: './users-fromjson-placeholder.component.html',
  styleUrls: ['./users-fromjson-placeholder.component.css']
})
export class UsersFromjsonPlaceholderComponent implements OnInit{
  usersArr:any;
  searchTerm:string;
  searchFieldArr:any;
  sortField:string;
  sortOrder:string;
  constructor( private talkWithServer:TalkWithServerService)
  {
    this.searchTerm="";
    this.usersArr=[];
    this.searchFieldArr=['username'];
    this.sortField="username";
    this.sortOrder="asc";
  }
  ngOnInit(): void {
    this.talkWithServer.getAllUsersFromJsonPlaceHolder()
    .pipe(map(
      (item:any)=>{
        var newItem=item.map((value:any)=> {
          // mask the first 3 digits of phone;
          var phone="***"+value.phone.substr(3);
          return {...value,phone:phone};
        })
        return newItem;
      }
    ))
    .subscribe((response)=>{
      console.log("Response of get request",response);
      this.usersArr=response;
      // sorting the array based on username
      // filtering the array based on condition

    })
  }
  toggleSortOrderForUserName()
  {
    this.sortField="username";
    this.sortOrder=this.sortOrder=="asc"?"desc":"asc";
  }

}
