import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnimationExamplesComponent } from './animation-examples.component';

describe('AnimationExamplesComponent', () => {
  let component: AnimationExamplesComponent;
  let fixture: ComponentFixture<AnimationExamplesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AnimationExamplesComponent]
    });
    fixture = TestBed.createComponent(AnimationExamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
