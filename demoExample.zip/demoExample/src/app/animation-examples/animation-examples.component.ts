import { animate, keyframes, state, style, transition, trigger } from '@angular/animations';
import { Component } from '@angular/core';

@Component({
  selector: 'app-animation-examples',
  templateUrl: './animation-examples.component.html',
  styleUrls: ['./animation-examples.component.css'],
  animations: [
    trigger("openClose", [
      state("open", style({
        height: '300px',
        backgroundColor: "yellow",
        opacity: 1
      })),

      state("closed", style({
        height: "150px",
        backgroundColor: "blue",
        color: "white"
      })),
      transition('open => closed', [animate('5s')]),
      transition("closed=> open", [animate('5s', keyframes(
        [
          style({ backgroundColor: "red", offset: 0 }),
          style({ backgroundColor: "blue", offset: 0.2 }),
          style({ backgroundColor: "orange", offset: 0.3 }),
          style({ backgroundColor: "black", offset: 1 })
        ]
      ))])
    ])]
  //animation triggers ]
})
export class AnimationExamplesComponent {
  showOpen: boolean;
  constructor() {
    this.showOpen = true;
  }
  toggleStateEventHandler() {
    this.showOpen = !this.showOpen;
  }
}
