import { IndianNumberFormatPipe } from './indian-number-format.pipe';

describe('IndianNumberFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new IndianNumberFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
