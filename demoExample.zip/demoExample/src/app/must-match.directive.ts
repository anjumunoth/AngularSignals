import { Directive, Input } from '@angular/core';
import { AbstractControl, FormGroup, NG_VALIDATORS, ValidationErrors, Validator } from '@angular/forms';
import { passwordsMustMatch } from './ValidatorFunctions/passwordsMustMatch';

@Directive({
  selector: '[mustMatch]',
  providers:[
    {provide:NG_VALIDATORS,useExisting:MustMatchDirective,multi:true}
  ]
})
export class MustMatchDirective implements Validator{
@Input() mustMatch:string[];
  constructor() {
    this.mustMatch=[];
   }
  validate(formGroup: FormGroup): ValidationErrors | null {
    return passwordsMustMatch(this.mustMatch)(formGroup);
  }
  

}
