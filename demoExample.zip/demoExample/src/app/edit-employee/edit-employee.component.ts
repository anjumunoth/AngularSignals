import { Component, EventEmitter, Input, Output, model } from '@angular/core';

@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employee.component.html',
  styleUrls: ['./edit-employee.component.css']
})
export class EditEmployeeComponent {
  // @Input() editableEmp:any;
  // @Output() editableEmpChange:EventEmitter<any>;
  editableEmp = model<any>()
  deptIdArr: any;
  constructor() {
    this.deptIdArr = ["D1", "D2", "D3", "D4", "D5"]
    // this.editableEmp=null;
    // this.editableEmpChange=new EventEmitter<any>();

  }

}
