import { Injectable } from '@angular/core';

@Injectable()
export class CartManagementService {
  private cartsArr:any;
  constructor() { 
    this.cartsArr=[];
  }
  addItem(cartObj:any)
  {
    //this.cartsArr.push(cartObj);
    var pos=this.cartsArr.findIndex((item:any) => item.productId == cartObj.productId)
    if(pos >=0)
    {
      this.cartsArr[pos].quantitySelected+=cartObj.quantitySelected;
    }
    else
    {
      this.cartsArr.push(cartObj);
    }
  }
  getCartsArr()
  {
    return this.cartsArr;
  }
}
