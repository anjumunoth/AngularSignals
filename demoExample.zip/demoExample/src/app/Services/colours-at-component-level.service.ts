import { Injectable } from '@angular/core';

@Injectable()
export class ColoursAtComponentLevelService {
  // A Service which will be injected at component level
  myColor:string;
  constructor() {
    this.myColor="pink";
   }

   changeColour(newColour:string)
   {
    this.myColor=newColour;
   }
}
