import { Injectable } from '@angular/core';
import { delay, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SearchDataService {
  dataArr:any;
  constructor() {
    this.dataArr=["red","green","blue","violet","black","yellow","cyan","aqua"];
   }
   searchData(searchTerm:any)
   {
      // get request to the server;
      console.log("Get request received");
      var newArr=this.dataArr.filter((item:any) => item.length == searchTerm.length)
      return of(newArr).pipe(delay(1000));

   }
}
