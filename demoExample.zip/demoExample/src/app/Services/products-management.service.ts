import { Injectable } from '@angular/core';
import { Products } from '../Products';

@Injectable({
  providedIn: 'root'
})
export class ProductsManagementService {
  ctr:number;
  private productsArr:Array<Products>;
  constructor() { 
    this.ctr=1;
    this.productsArr=[
      new Products(101,"Iphone 15 max pro",112345,12,"../assets/iphone15ProMax.jpg","Apple Iphone 15 pro max 256gb white colour"),
      new Products(102,"Google Pixel 8",11345,1,"../assets/googlePixel8.jpg","Apple Iphone 15 pro max 256gb white colour"),
      new Products(103,"One plus 8t",56782,5,"../assets/oneplus8T.jpg","Apple Iphone 15 pro max 256gb white colour"),
      new Products(104,"Samsung Fold",151345,7,"../assets/samsungFold.jpg","Apple Iphone 15 pro max 256gb white colour"),
      new Products(105,"Vivo Y 16",12345,9,"../assets/vivoY16.jpg","Apple Iphone 15 pro max 256gb white colour"),
    ];
  }
  incCtr()
  {
    this.ctr++;
  }
  getProductsArr():Array<Products>
  {
    return this.productsArr;
    // return [...this.productsArr];
  }
}
