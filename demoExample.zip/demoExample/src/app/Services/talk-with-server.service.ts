import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, NEVER, of, retry, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TalkWithServerService {
  serverUrl:string;
  constructor(private httpClient:HttpClient) {
    this.serverUrl="";
   }

   getAllUsersFromJsonPlaceHolder()
   {
    // get request
      this.serverUrl="https://jsonplaceholder.typicode.com/users"
      return (
        this.httpClient.get(this.serverUrl)
        .pipe(
          catchError(this.handleError)
        )
    )

   }

   getAllUsersFromReqRes()
   {

    var params:HttpParams=new HttpParams();
    params.set("page",2);
    this.serverUrl="https://reqres.in/api/users";

    return this.httpClient.get(this.serverUrl,{params:params,observe:"response"})
    .pipe(
      retry(3),
      catchError(this.handleError)
    )
   }
   private handleError(error:HttpErrorResponse)
   {
    console.log("MyError in requests to the API ",error);
    if(error.status ==0)
    {
      // error on the client side
      console.log("An error occured on the client side",error);
    }
    else
    {
      // response code 400's or 500's
      console.log("Error on the server side",error);
    }

    // return an observable or throw an error
    //return of({body:{data:[]}});
    return throwError(()=>{
      return new Error("Error occured. Pls try again");
    })

   }
   addUser(newUser:any)
   {
    this.serverUrl="https://reqres.in/api/users";

    // header infor
    var headers:HttpHeaders=new HttpHeaders(
      {
        "content-type":"application/json"
      }
    );
    
      return this.httpClient.post(this.serverUrl,newUser,{headers:headers,observe:"response"})
   }
}
