import { CheckDateOfBirthDirective } from './check-date-of-birth.directive';

describe('CheckDateOfBirthDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckDateOfBirthDirective();
    expect(directive).toBeTruthy();
  });
});
