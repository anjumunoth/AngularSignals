import { ChangeDetectionStrategy, Component, DoCheck, Input } from '@angular/core';

@Component({
  selector: 'app-change-detection-child',
  templateUrl: './change-detection-child.component.html',
  styleUrls: ['./change-detection-child.component.css'],
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class ChangeDetectionChildComponent implements DoCheck{
@Input() companyName:string;
@Input() counter:any;
@Input() num1:number;
constructor()
{
  this.companyName="";
  this.num1=0;
}
ngDoCheck(): void {
  console.log("Do check called for child component");
}
}
