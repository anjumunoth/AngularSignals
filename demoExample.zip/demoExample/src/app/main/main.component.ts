import { Component } from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent {
showHome:boolean;
constructor()
{
  this.showHome=true;
}
toggleComponent(result:boolean)
{
  this.showHome=result;
}
}
